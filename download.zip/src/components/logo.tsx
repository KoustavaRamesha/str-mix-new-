import { cn } from '@/lib/utils';
import Link from 'next/link';
import { Construction } from 'lucide-react';

export function Logo({ className }: { className?: string }) {
  return (
    <Link
      href="/"
      className={cn(
        'flex items-center gap-2 font-headline text-2xl font-black tracking-tighter text-foreground transition-opacity hover:opacity-80',
        className
      )}
    >
      <Construction className="h-8 w-8 text-primary" />
      <span>
        STR<span className="font-medium text-primary">MIX</span>
      </span>
    </Link>
  );
}
