import Image from 'next/image';
import Link from 'next/link';
import { ArrowRight, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import { Badge } from '@/components/ui/badge';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { products, testimonials } from '@/lib/data';

export default function Home() {
  const heroImage = PlaceHolderImages.find(p => p.id === 'hero-homepage');
  const serviceImage = PlaceHolderImages.find(p => p.id === 'service-boom-pump-small');
  const galleryImages = PlaceHolderImages.filter(p => p.id.startsWith('gallery-preview'));

  return (
    <div className="flex flex-col animate-in fade-in duration-500">
      {/* Hero Section */}
      <section className="relative h-[60vh] w-full">
        {heroImage && (
          <Image
            src={heroImage.imageUrl}
            alt={heroImage.description}
            fill
            className="object-cover"
            priority
            data-ai-hint={heroImage.imageHint}
          />
        )}
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative z-10 flex h-full flex-col items-center justify-center text-center text-white p-4">
          <h1 className="font-headline text-4xl md:text-6xl font-bold">
            Building the Foundations of Tomorrow
          </h1>
          <p className="mt-4 max-w-2xl text-lg md:text-xl text-white/90">
            STR MIX delivers premium ready-mix concrete and expert boom pump services for projects of any scale.
          </p>
          <Button asChild size="lg" className="mt-8 bg-accent hover:bg-accent/90 text-accent-foreground">
            <Link href="/contact">
              Get a Free Quote <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="text-center">
            <h2 className="font-headline text-3xl md:text-4xl font-bold">Our Concrete Products</h2>
            <p className="mt-4 max-w-2xl mx-auto text-muted-foreground">
              From foundational work to specialized applications, we have the right mix for you.
            </p>
          </div>
          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.slice(0, 4).map((product) => (
              <Card key={product.name} className="flex flex-col transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="font-headline">{product.name} Grade</span>
                    <Badge variant="secondary">{product.strength}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-muted-foreground">{product.use}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-12">
            <Button asChild variant="outline">
              <Link href="/products">View All Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container grid md:grid-cols-2 gap-12 items-center">
          <div className="rounded-lg overflow-hidden shadow-lg">
            {serviceImage && (
              <Image
                src={serviceImage.imageUrl}
                alt={serviceImage.description}
                width={600}
                height={400}
                className="w-full h-auto object-cover"
                data-ai-hint={serviceImage.imageHint}
              />
            )}
          </div>
          <div>
            <h2 className="font-headline text-3xl md:text-4xl font-bold">Efficient Boom Pump Services</h2>
            <p className="mt-4 text-muted-foreground">
              Our state-of-the-art boom pumps allow for precise and rapid concrete placement, even in the most challenging locations. Save time and labor costs on your next project with STR MIX.
            </p>
            <ul className="mt-6 space-y-2 text-muted-foreground">
              <li className="flex items-center gap-2">✓ Vertical and horizontal reach</li>
              <li className="flex items-center gap-2">✓ Suitable for high-rise buildings and large slabs</li>
              <li className="flex items-center gap-2">✓ Operated by certified professionals</li>
            </ul>
            <Button asChild className="mt-8 bg-accent hover:bg-accent/90 text-accent-foreground">
              <Link href="/services">Learn More</Link>
            </Button>
          </div>
        </div>
      </section>
      
      {/* Gallery Preview */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="text-center">
            <h2 className="font-headline text-3xl md:text-4xl font-bold">Project Showcase</h2>
            <p className="mt-4 max-w-2xl mx-auto text-muted-foreground">
              See the quality and scale of our work in action.
            </p>
          </div>
          <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 gap-4">
            {galleryImages.map((image) => (
              <div key={image.id} className="relative aspect-square overflow-hidden rounded-lg shadow-md transition-transform duration-300 hover:scale-105">
                <Image
                  src={image.imageUrl}
                  alt={image.description}
                  fill
                  className="object-cover"
                  data-ai-hint={image.imageHint}
                />
              </div>
            ))}
          </div>
           <div className="text-center mt-12">
            <Button asChild variant="outline">
              <Link href="/gallery">Explore Gallery</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container">
          <div className="text-center">
            <h2 className="font-headline text-3xl md:text-4xl font-bold">What Our Clients Say</h2>
          </div>
          <Carousel
            opts={{ align: 'start', loop: true }}
            className="w-full max-w-4xl mx-auto mt-12"
          >
            <CarouselContent>
              {testimonials.map((testimonial, index) => (
                <CarouselItem key={index} className="md:basis-1/2">
                  <div className="p-1">
                    <Card>
                      <CardContent className="flex aspect-video flex-col justify-center p-6">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className="h-5 w-5 text-primary fill-primary" />
                          ))}
                        </div>
                        <p className="mt-4 text-muted-foreground italic">"{testimonial.quote}"</p>
                        <p className="mt-4 font-bold text-right">- {testimonial.author}</p>
                      </CardContent>
                    </Card>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious />
            <CarouselNext />
          </Carousel>
        </div>
      </section>
    </div>
  );
}
