'use server';

import { z } from 'zod';

const contactSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters.'),
  email: z.string().email('Invalid email address.'),
  phone: z.string().optional(),
  subject: z.string().min(3, 'Subject must be at least 3 characters.'),
  message: z.string().min(10, 'Message must be at least 10 characters.'),
});

const reviewSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters.'),
  rating: z.coerce.number().min(1, "Please select a rating.").max(5),
  review: z.string().min(10, 'Review must be at least 10 characters.'),
});

type FormState = {
  message: string;
  success: boolean;
  errors?: Record<string, string[] | undefined>;
};

export async function handleContactSubmission(
  prevState: FormState,
  formData: FormData
): Promise<FormState> {
  const validatedFields = contactSchema.safeParse(Object.fromEntries(formData.entries()));

  if (!validatedFields.success) {
    return {
      message: 'Validation failed. Please check your input.',
      success: false,
      errors: validatedFields.error.flatten().fieldErrors,
    };
  }
  
  // In a real application, you would send an email, save to a database, etc.
  console.log('New Contact Inquiry:', validatedFields.data);

  return { message: 'Thank you for your inquiry! We will get back to you shortly.', success: true };
}

export async function handleReviewSubmission(
  prevState: FormState,
  formData: FormData
): Promise<FormState> {
    const validatedFields = reviewSchema.safeParse(Object.fromEntries(formData.entries()));

  if (!validatedFields.success) {
    return {
      message: 'Validation failed. Please check your input.',
      success: false,
      errors: validatedFields.error.flatten().fieldErrors,
    };
  }

  // In a real application, you would save this to a database for moderation.
  console.log('New Review Submitted:', validatedFields.data);

  return { message: 'Thank you for your review! It has been submitted for approval.', success: true };
}
